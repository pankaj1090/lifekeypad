 <div id="preloader">
	<div id="status"><img src="<?php echo $basepath; ?>assets/frontend/img/loading.gif" id="preloader_image" alt="loader">
	</div>
</div>
 <div id="page-content" class="home-slider-content">
    <div class="container">
      <div class="home-with-slide">
        <div class="row">

          <div class="col-md-9 col-md-push-3">
            <div class="page-content">

              ,<!--<div class="change-view">
                <div class="filter-input">
                  <input type="text" placeholder="Filter by Keywords">
                </div>
              </div> --><!-- end .change-view -->


              <div class="product-details">
                <div class="tab-content">

				  <?php if(!empty($main_category)){
					   $sno = 0;
					  foreach($main_category as $solo_cate){
					  $uniqid = $solo_cate['id'];

					  if($sno == 0){
						  $cls = "active";
						  $sno++;
					  } 
					  else { $cls = ""; }   	
					  $sub_categories = $this->Main_model->access_data('id,slug,title,fa-icon','categories','','','',array('parent'=>$uniqid)); 
						$all_sub_categories = "";
						$cnt = '0';
						if(!empty($sub_categories)){
							foreach($sub_categories as $solo_subcate){ 
								 $subcate_count =  $this->Main_model->aggregate_data('relation' , 'company' , 'COUNT' , array('category'=>$solo_subcate['id']));
								if($subcate_count != '0'){
									$all_sub_categories .= '<div class="col-md-3 col-sm-4 col-xs-6"><div class="category-item"><a href="'.$basepath.'home/search/'.$solo_cate['slug'].'/'.$solo_subcate['slug'].'"><i class="fa fa-'.$solo_subcate['fa-icon'].'"></i>'.$solo_subcate['title'].'</a></div></div>';
								$cnt++;
								}
							}	
						  }
					  
					  ?>
                  <div class="tab-pane <?php echo $cls;?>" id="cate_<?php echo $uniqid;?>">
                    <h3><?php echo $solo_cate['title'];?> <span class="comments"><?php echo $cnt;?></span></h3>

                    <div class="row clearfix">
                      <?php 
						echo $all_sub_categories;
					  ?>
					  <?php if(!empty($all_sub_categories)): ?>
                      <div class="view-more">
                        <a class="btn btn-default text-center" href="<?php echo $basepath.'home/search/'.$solo_cate['slug']; ?>"><i class="fa fa-plus-square-o"></i>View More</a>
                      </div>
					  <?php endif; ?>

                    </div> <!-- end .row -->
                  </div> <!-- end .tabe-pane -->
				<?php }
				  }  ?>



                </div> <!-- end .tabe-content -->

              </div> <!-- end .product-details -->
            </div> <!-- end .page-content -->
          </div>

          <div class="col-md-3 col-md-pull-9 category-toggle">
            <button><i class="fa fa-briefcase"></i></button>

            <div class="page-sidebar">
			<?php
             /*  <div class="custom-search">

                <div class="location-details">
                  <form action="#">
                    <div class="select-country">
                      <label>Country</label>

                      <select class="" data-placeholder="-Select-">
                        <option value="option1">option 1</option>
                        <option value="option2">option 2</option>
                        <option value="option3">option 3</option>
                        <option value="option4">option 4</option>
                      </select>

                    </div> <!-- end .select-country -->

                    <div class="select-state">
                      <label>State</label>

                      <select class="" data-placeholder="-Select-">
                        <option value="option1">option 1</option>
                        <option value="option2">option 2</option>
                        <option value="option3">option 3</option>
                        <option value="option4">option 4</option>
                      </select>

                    </div> <!-- end .select-state -->

                    <div class="zip-code">
                      <label>ZIP Code</label>

                      <input type="text" placeholder="Enter">

                    </div> <!-- end .zip-code -->
                  </form>

                </div> <!-- end .location-details -->

                <div class="distance-range">
                  <p>
                    <label for="amount">Distance</label>
                    <input type="text" id="amount">
                  </p>

                  <div id="slider-range-min"></div>
                </div>  <!-- end #distance-range -->
              </div> <!-- end .custom-search -->
 */
			 ?>
              <!-- Category accordion -->
              <div id="categories">
                <div class="accordion">
                  <ul class="nav nav-tabs home-tab" role="tablist">

				  <?php if(!empty($main_category)){
					  $sno = 0;
					  foreach($main_category as $solo_cate){
					  $uniqid = $solo_cate['id'];
					  if($sno == 0){
						  $cls = "active";
						  $sno++;
					  } else { $cls = ""; }
					  ?>
                    <li class="<?php echo $cls;?>">
                      <a href="#cate_<?php echo $uniqid;?>"  role="tab" data-toggle="tab"><?php echo $solo_cate['title']; ?>
                       <!-- <span>Display all sub-categories</span> -->
                      </a>
                    </li>
					<?php	}
				  } else { ?>
					   <li>
                      <a role="tab" data-toggle="tab">No Categories Listed</a>
                    </li>
				  <?php } ?>

                  </ul>
                </div> <!-- end .accordion -->
              </div> <!-- end #categories -->

            </div> <!-- end .page-sidebar -->
          </div> <!-- end grid layout-->
        </div> <!-- end .row -->
      </div> <!-- end .home-with-slide -->
    </div> <!-- end .container -->
  </div>  <!-- end #page-content -->


  <div class="featured-listing" id= "featured-list">
    <div class="container">
      <div class="row clearfix">
        <h2><strong>Featured</strong></h2>

		<?php if(!empty($shops_list)){
		foreach ($shops_list as $solo_shops) { ?>
   <a href="<?php  echo base_url().'company/'.$solo_shops['slug'];?>">
			<div class="col-md-3 col-sm-4 col-xs-6">
          <div class="single-product">
            <figure>
			<?php
			if(!empty($solo_shops['logo'])){
				$featuredlogoSrc = base_url().'assets/uploads/listing/'.$solo_shops['logo'];
			}else{ 
				$featuredlogoSrc = base_url().'assets/frontend/img/LOGO.png';
			}
			$rating_avg=$this->Main_model->aggregate_data('d_review','r_rating','avg',array('r_company'=>$solo_shops['id']));
			
			$rating_avg=round($rating_avg); 
			?>
              <img src="<?php echo $featuredlogoSrc;?>" alt="<?php echo $solo_shops['company_name'];?>">

                <div class="feature_tag">Featured</div>

              <figcaption>
                <div class="bookmark">
                  <a href="<?php  echo base_url().'company/'.$solo_shops['slug'];?>"><i class="fa fa-phone"></i> <?php echo $solo_shops['phone1'];?></a>
                </div>
                <div class="read-more">
                  <a href="<?php  echo base_url().'company/'.$solo_shops['slug'];?>"><i class="fa fa-angle-right"></i> View Shop</a>
                </div>

              </figcaption>
            </figure>
			<div class="dw_feature_caption">
				<h4><a href="<?php  echo base_url().'company/'.$solo_shops['slug'];?>"><?php echo $solo_shops['company_name'];?></a></h4>

				<h5><a href="<?php echo base_url().'home/search/'.$solo_shops['title'];?>"><?php echo $solo_shops['title'];?></a></h5>
				
				
				
				<div class="dw_rating_div">
                  <span class="star_rating <?php echo ($rating_avg >=1) ? 'rated' :''; ?>"><i class="fa fa-star" aria-hidden="true"></i></span>
                  <span class="star_rating <?php echo ($rating_avg >=2) ? 'rated' :''; ?>"><i class="fa fa-star" aria-hidden="true"></i></span>
                  <span class="star_rating <?php echo ($rating_avg >=3) ? 'rated' :''; ?>"><i class="fa fa-star" aria-hidden="true"></i></span>
                  <span class="star_rating <?php echo ($rating_avg >=4) ? 'rated' :''; ?>"><i class="fa fa-star" aria-hidden="true"></i></span>
                  <span class="star_rating <?php echo ($rating_avg >=5) ? 'rated' :''; ?>"><i class="fa fa-star" aria-hidden="true"></i></span>
              </div>
			</div>
          </div> <!-- end .single-product -->

        </div>
		</a>
		<?php } }?>




      </div>  <!-- end .row -->

      <div class="discover-more">

        <a class="btn btn-default text-center" href="#"><i class="fa fa-plus-square-o"></i>Discover More</a>
      </div>
    </div>  <!-- end .container -->
  </div>  <!-- end .featured-listing -->


  <div class="classifieds-content">
    <div class="container">
      <div class="heading-section clearfix">
        <h1>Classifieds</h1>

        <a href="#" class="btn btn-default"><i class="fa fa-plus"></i> Post Your Ad</a>

        <!--<form action="#">
          <input type="text" placeholder="Search by keywords">

          <button type="submit"><i class="fa fa-search"></i></button>
        </form>-->
      </div> <!-- END .heading-section -->

      <!-- CLSSIFIEDS-CATEGROY BEGIN -->
		<div class="row">
			<div class="col-md-3 col-sm-6"> 
				<ul class="classifieds-category">

			   <?php 
				
			   if(!empty($main_category)){
					$count = 1;		
					foreach($main_category as $solo_cate){
					$uniqid = $solo_cate['id'];
					
					  $sub_categories = $this->Main_model->access_database('categories','select','',array('parent'=>$uniqid));
					  $cate_count = $this->Main_model->aggregate_data('company' , 'id' , 'COUNT' , array('category'=>$uniqid));
					  
					  //count( $this->Main_model->access_database('company','select','',array('category'=>$uniqid)) );
					?>



					<li><a href="<?php echo $basepath.'home/search/'.$solo_cate['slug']; ?>"><i class="fa fa-<?php echo $solo_cate['fa-icon'];?>"></i><?php echo $solo_cate['title'];?> <span>(<?php echo $cate_count;?>)</span></a>

					  <ul class="sub-category">
					   <?php  foreach($sub_categories as $solo_subcate){
					   $subcate_count =  $this->Main_model->aggregate_data('relation' , 'company' , 'COUNT' , array('category'=>$solo_subcate['id']));

					   //count( $this->Main_model->access_database('relation','select','',array('category'=>$solo_subcate['id'])) );
						if($subcate_count != '0'){	
					   ?>
						<li><a href="<?php echo $basepath.'home/search/'.$solo_cate['slug'].'/'.$solo_subcate['slug']; ?>"><?php echo $solo_subcate['title']; ?> <span>(<?php echo $subcate_count;?>)</span></a></li>
					   <?php
							}
					   } ?>
					  </ul>
 
					</li>
			   <?php
			   if($count%floor(count($main_category)/4) == 0){
						//echo '  </ul> <!-- END MAIN UL -->
				 // <!-- END .CLASSIFIES-CATEGORY --></div> <!-- End grid layout -->';
					echo '</ul> 
						</div>
						<div class="col-md-3 col-sm-6">
							<ul class="classifieds-category">';
					} $count++;
					 }  } ?>
				</ul>
			</div>			
		</div> <!-- End .row -->
    </div> <!-- END .container-->
  </div> <!-- classifieds-content -->


  <?php /*<div class="register-content">
    <div class="reg-heading">
      <h1><strong>Register</strong> now</h1>
    </div>

    <div class="registration-details">
      <div class="container">
        <div class="box regular-member">
          <h2><strong>Regular</strong> Member</h2>

          <p><i class="fa fa-check-circle-o"></i> Loren ipsum dolor sit amet</p>
          <p><i class="fa fa-check-circle-o"></i> Loren ipsum dolor sit amet</p>
          <p><i class="fa fa-check-circle-o"></i> Loren ipsum dolor sit amet</p>
			<?php if(!isset($this->session->userdata['role'])){ 
				echo ' <a data-toggle="modal" data-target="#exampleModal" class="btn btn-default-inverse"><i class="fa fa-plus"></i> Register Now</a>';
			} ?>
         
        </div>

        <div class="alternate">
          <h2>OR</h2>
        </div>

        <div class="box business-member">   
          <h2><strong>Business</strong> Member</h2>

          <p><i class="fa fa-check-circle-o"></i> Loren ipsum dolor sit amet</p>
          <p><i class="fa fa-check-circle-o"></i> Loren ipsum dolor sit amet</p>
          <p><i class="fa fa-check-circle-o"></i> Loren ipsum dolor sit amet</p>

         <?php if(!isset($this->session->userdata['role'])){ 
				echo ' <a data-toggle="modal" data-target="#exampleModal" class="btn btn-default-inverse"><i class="fa fa-plus"></i> Register Now</a>';
			} ?>
        </div>

      </div>
      <!-- END .CONTAINER -->
    </div>
    <!-- END .REGISTRATION-DETAILS -->
  </div> */ ?>
  <!-- END REGISTER-CONTENT -->

  <!-- OUR PARTNER SLIDER BEGIN -->
    <div class="our-partners">
      <div class="container">
        <h4>Our Partners</h4>

        <div id="partners-slider" class="owl-carousel owl-theme">
		<?php 
		$partner_detail = $this->Main_model->access_database('our_partner','select','','');
		if(!empty($partner_detail)){
			foreach($partner_detail as $partner){
			?>
			 <div class="item"><a href="javascript:;"><img src="<?php echo $basepath.'/assets/uploads/partner/'.$partner['logo_name']; ?>" alt=""></a></div>
			<?php
			}
		}
		?>
        </div>
      </div>
    </div>
    <!-- END OUR PARTNER SLIDER -->